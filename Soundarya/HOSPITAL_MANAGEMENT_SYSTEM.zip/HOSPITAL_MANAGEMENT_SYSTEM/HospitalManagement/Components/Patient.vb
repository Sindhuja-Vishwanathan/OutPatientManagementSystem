﻿Public Class Patient

End Class
