﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FindPatients
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FindPatients))
        Me.lblPatientName = New System.Windows.Forms.Label()
        Me.lblDoctorName = New System.Windows.Forms.Label()
        Me.txtPatientName = New System.Windows.Forms.TextBox()
        Me.cmbDoctorName = New System.Windows.Forms.ComboBox()
        Me.btnSearch = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblPatientName
        '
        Me.lblPatientName.BackColor = System.Drawing.Color.Blue
        Me.lblPatientName.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblPatientName.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPatientName.Location = New System.Drawing.Point(57, 34)
        Me.lblPatientName.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblPatientName.Name = "lblPatientName"
        Me.lblPatientName.Size = New System.Drawing.Size(128, 34)
        Me.lblPatientName.TabIndex = 0
        Me.lblPatientName.Text = "Patient Name:"
        Me.lblPatientName.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblDoctorName
        '
        Me.lblDoctorName.BackColor = System.Drawing.Color.Blue
        Me.lblDoctorName.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDoctorName.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDoctorName.Location = New System.Drawing.Point(57, 89)
        Me.lblDoctorName.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblDoctorName.Name = "lblDoctorName"
        Me.lblDoctorName.Size = New System.Drawing.Size(128, 34)
        Me.lblDoctorName.TabIndex = 1
        Me.lblDoctorName.Text = "Doctor Name:"
        Me.lblDoctorName.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtPatientName
        '
        Me.txtPatientName.BackColor = System.Drawing.SystemColors.Info
        Me.txtPatientName.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPatientName.Location = New System.Drawing.Point(282, 34)
        Me.txtPatientName.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtPatientName.Name = "txtPatientName"
        Me.txtPatientName.Size = New System.Drawing.Size(129, 23)
        Me.txtPatientName.TabIndex = 2
        '
        'cmbDoctorName
        '
        Me.cmbDoctorName.BackColor = System.Drawing.SystemColors.Info
        Me.cmbDoctorName.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbDoctorName.FormattingEnabled = True
        Me.cmbDoctorName.Location = New System.Drawing.Point(282, 89)
        Me.cmbDoctorName.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.cmbDoctorName.Name = "cmbDoctorName"
        Me.cmbDoctorName.Size = New System.Drawing.Size(129, 24)
        Me.cmbDoctorName.TabIndex = 3
        '
        'btnSearch
        '
        Me.btnSearch.BackColor = System.Drawing.Color.OrangeRed
        Me.btnSearch.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSearch.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnSearch.Location = New System.Drawing.Point(189, 192)
        Me.btnSearch.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(145, 50)
        Me.btnSearch.TabIndex = 4
        Me.btnSearch.Text = "Search"
        Me.btnSearch.UseVisualStyleBackColor = False
        '
        'FindPatients
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.GrayText
        Me.ClientSize = New System.Drawing.Size(533, 292)
        Me.Controls.Add(Me.btnSearch)
        Me.Controls.Add(Me.cmbDoctorName)
        Me.Controls.Add(Me.txtPatientName)
        Me.Controls.Add(Me.lblDoctorName)
        Me.Controls.Add(Me.lblPatientName)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Name = "FindPatients"
        Me.Text = "FindPatients"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblPatientName As Label
    Friend WithEvents lblDoctorName As Label
    Friend WithEvents txtPatientName As TextBox
    Friend WithEvents cmbDoctorName As ComboBox
    Friend WithEvents btnSearch As Button
End Class
