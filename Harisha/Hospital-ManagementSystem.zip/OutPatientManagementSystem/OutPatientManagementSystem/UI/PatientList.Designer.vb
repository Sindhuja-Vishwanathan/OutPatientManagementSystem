﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PatientList
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(PatientList))
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.UpdatePatientToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DeletePatientToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.grdPatient = New System.Windows.Forms.DataGridView()
        Me.ContextMenuStrip1.SuspendLayout()
        CType(Me.grdPatient, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.ImageScalingSize = New System.Drawing.Size(24, 24)
        Me.ContextMenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.UpdatePatientToolStripMenuItem, Me.DeletePatientToolStripMenuItem})
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(150, 48)
        '
        'UpdatePatientToolStripMenuItem
        '
        Me.UpdatePatientToolStripMenuItem.Name = "UpdatePatientToolStripMenuItem"
        Me.UpdatePatientToolStripMenuItem.Size = New System.Drawing.Size(149, 22)
        Me.UpdatePatientToolStripMenuItem.Text = "UpdatePatient"
        '
        'DeletePatientToolStripMenuItem
        '
        Me.DeletePatientToolStripMenuItem.Name = "DeletePatientToolStripMenuItem"
        Me.DeletePatientToolStripMenuItem.Size = New System.Drawing.Size(149, 22)
        Me.DeletePatientToolStripMenuItem.Text = "DeletePatient"
        '
        'grdPatient
        '
        Me.grdPatient.AllowUserToAddRows = False
        Me.grdPatient.AllowUserToDeleteRows = False
        Me.grdPatient.AllowUserToResizeColumns = False
        Me.grdPatient.AllowUserToResizeRows = False
        Me.grdPatient.BackgroundColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.grdPatient.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        Me.grdPatient.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdPatient.GridColor = System.Drawing.SystemColors.GrayText
        Me.grdPatient.Location = New System.Drawing.Point(8, 8)
        Me.grdPatient.Margin = New System.Windows.Forms.Padding(2)
        Me.grdPatient.Name = "grdPatient"
        Me.grdPatient.ReadOnly = True
        Me.grdPatient.RowHeadersVisible = False
        Me.grdPatient.RowHeadersWidth = 62
        Me.grdPatient.RowTemplate.Height = 28
        Me.grdPatient.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grdPatient.Size = New System.Drawing.Size(772, 309)
        Me.grdPatient.TabIndex = 1
        '
        'PatientList
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Green
        Me.ClientSize = New System.Drawing.Size(821, 435)
        Me.Controls.Add(Me.grdPatient)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "PatientList"
        Me.Text = "PatientList"
        Me.ContextMenuStrip1.ResumeLayout(False)
        CType(Me.grdPatient, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents ContextMenuStrip1 As ContextMenuStrip
    Friend WithEvents UpdatePatientToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DeletePatientToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents grdPatient As DataGridView
End Class
