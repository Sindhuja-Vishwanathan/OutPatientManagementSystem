﻿Imports ClassLib

Public Class HomePage

    Dim pageReg As PatientRegister
    Dim pageList As PatientList
    Dim docList As DoctorList
    Dim log As New EventLog
    Private Sub RegisterToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RegisterToolStripMenuItem.Click
        Try
            If pageReg Is Nothing Then
                pageReg = New PatientRegister
                pageReg.MdiParent = Me
                pageReg.Show()
            Else pageReg.Activate()
            End If

        Catch ex As Exception
            With log
                .Source = "OutPatientManagementSystem"
                .Log = "OPMSLog"
                .EnableRaisingEvents = True
                .WriteEntry(ex.Message, EventLogEntryType.Error)
            End With
            Throw ex
        End Try
    End Sub

    Public Sub PatientRegisterClose()
        pageReg = Nothing
    End Sub
    Private Sub CloseToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CloseToolStripMenuItem.Click
        Try

            Dim msg = "Are you sure to Exit?"
            Dim title = "OPMS"
            Dim buttons As MessageBoxButtons = MessageBoxButtons.OKCancel
            Dim result As DialogResult = MessageBox.Show(msg, title, buttons, MessageBoxIcon.Question)
            If result = DialogResult.OK Then
                Application.Exit()
                With log
                    .Source = "OutPatientManagementSystem"
                    .Log = "OPMSLog"
                    .EnableRaisingEvents = True
                    .WriteEntry("Application Exited", EventLogEntryType.Information)
                End With
            End If
        Catch ex As Exception
            With log
                .Source = "OutPatientManagementSystem"
                .Log = "OPMSLog"
                .EnableRaisingEvents = True
                .WriteEntry(ex.Message, EventLogEntryType.Error)
            End With
            Throw ex
        End Try
    End Sub

    Private Shared component As IDBComponent = DataFactory.GetComponent
    Private Sub ListToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ListToolStripMenuItem.Click
        Try
            If pageList Is Nothing Then
                pageList = New PatientList
                pageList.MdiParent = Me
                pageList.table = component.GetAllPatient
                pageList.Show()
            Else pageList.Activate()
            End If

        Catch ex As Exception
            With log
                .Source = "OutPatientManagementSystem"
                .Log = "OPMSLog"
                .EnableRaisingEvents = True
                .WriteEntry(ex.Message, EventLogEntryType.Error)
            End With
            Throw ex
        End Try
    End Sub

    Public Sub PatientListClose()
        pageList = Nothing
    End Sub

    Private Sub ListToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles ListToolStripMenuItem1.Click
        Try
            If docList Is Nothing Then
                docList = New DoctorList
                docList.MdiParent = Me
                docList.Show()
            Else docList.Activate()
            End If

        Catch ex As Exception
            With log
                .Source = "OutPatientManagementSystem"
                .Log = "OPMSLog"
                .EnableRaisingEvents = True
                .WriteEntry(ex.Message, EventLogEntryType.Error)
            End With
            Throw ex
        End Try
    End Sub

    Public Sub DoctorListClose()
        docList = Nothing
    End Sub

    Private Sub HomeToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HomeToolStripMenuItem.Click
        Try
            My.Application.OpenForms.Cast(Of Form)() _
              .Except({Me}) _
              .ToList() _
              .ForEach(Sub(form) form.Close())
            Me.Activate()
        Catch ex As Exception
            With log
                .Source = "OutPatientManagementSystem"
                .Log = "OPMSLog"
                .EnableRaisingEvents = True
                .WriteEntry(ex.Message, EventLogEntryType.Error)
            End With
            Throw ex
        End Try
    End Sub
    Public search As FindPatients
    Private Sub FindToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles FindToolStripMenuItem.Click
        Try
            If search Is Nothing Then
                search = New FindPatients
                search.MdiParent = Me
                search.Show()
            Else search.Activate()
            End If
        Catch ex As Exception
            With log
                .Source = "OutPatientManagementSystem"
                .Log = "OPMSLog"
                .EnableRaisingEvents = True
                .WriteEntry(ex.Message, EventLogEntryType.Error)
            End With
            Throw ex
        End Try
    End Sub


    Private Sub HomePage_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If Not EventLog.SourceExists("OutPatientManagementSystem") Then
            EventLog.CreateEventSource("OutPatientManagementSystem", "OPMSLog")
        End If
    End Sub
End Class
