﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class PatientRegister
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(PatientRegister))
        Me.btnInsert = New System.Windows.Forms.Button()
        Me.Patient1 = New OutPatientManagementSystem.Patient()
        Me.SuspendLayout()
        '
        'btnInsert
        '
        Me.btnInsert.Location = New System.Drawing.Point(164, 406)
        Me.btnInsert.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.btnInsert.Name = "btnInsert"
        Me.btnInsert.Size = New System.Drawing.Size(132, 35)
        Me.btnInsert.TabIndex = 1
        Me.btnInsert.Text = "INSERT"
        Me.btnInsert.UseVisualStyleBackColor = True
        '
        'Patient1
        '
        Me.Patient1.BackColor = System.Drawing.SystemColors.GrayText
        Me.Patient1.Location = New System.Drawing.Point(55, 21)
        Me.Patient1.Margin = New System.Windows.Forms.Padding(1, 1, 1, 1)
        Me.Patient1.Name = "Patient1"
        Me.Patient1.Size = New System.Drawing.Size(373, 381)
        Me.Patient1.TabIndex = 2
        '
        'PatientRegister
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Green
        Me.ClientSize = New System.Drawing.Size(503, 480)
        Me.Controls.Add(Me.btnInsert)
        Me.Controls.Add(Me.Patient1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Name = "PatientRegister"
        Me.Text = "PatientRegister"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btnInsert As Button
    Friend WithEvents Patient1 As Patient
End Class
