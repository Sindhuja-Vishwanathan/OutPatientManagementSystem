﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class DoctorList
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(DoctorList))
        Me.grdDoctors = New System.Windows.Forms.DataGridView()
        CType(Me.grdDoctors, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'grdDoctors
        '
        Me.grdDoctors.AllowUserToAddRows = False
        Me.grdDoctors.AllowUserToDeleteRows = False
        Me.grdDoctors.AllowUserToResizeColumns = False
        Me.grdDoctors.AllowUserToResizeRows = False
        Me.grdDoctors.BackgroundColor = System.Drawing.SystemColors.Highlight
        Me.grdDoctors.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdDoctors.GridColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.grdDoctors.Location = New System.Drawing.Point(15, 8)
        Me.grdDoctors.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.grdDoctors.Name = "grdDoctors"
        Me.grdDoctors.ReadOnly = True
        Me.grdDoctors.RowHeadersVisible = False
        Me.grdDoctors.RowHeadersWidth = 62
        Me.grdDoctors.RowTemplate.Height = 28
        Me.grdDoctors.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grdDoctors.Size = New System.Drawing.Size(729, 341)
        Me.grdDoctors.TabIndex = 0
        '
        'DoctorList
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.GrayText
        Me.ClientSize = New System.Drawing.Size(769, 436)
        Me.Controls.Add(Me.grdDoctors)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Name = "DoctorList"
        Me.Text = "DoctorList"
        CType(Me.grdDoctors, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents grdDoctors As DataGridView
End Class
