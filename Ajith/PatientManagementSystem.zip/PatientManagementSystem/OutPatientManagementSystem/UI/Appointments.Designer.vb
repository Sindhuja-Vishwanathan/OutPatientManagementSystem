﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Appointments
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.RegisterToolStripMenuItem = New System.Windows.Forms.LinkLabel()
        Me.ListToolStripMenuItem = New System.Windows.Forms.LinkLabel()
        Me.FindToolStripMenuItem = New System.Windows.Forms.LinkLabel()
        Me.SuspendLayout()
        '
        'RegisterToolStripMenuItem
        '
        Me.RegisterToolStripMenuItem.AutoSize = True
        Me.RegisterToolStripMenuItem.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold)
        Me.RegisterToolStripMenuItem.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.RegisterToolStripMenuItem.LinkColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.RegisterToolStripMenuItem.Location = New System.Drawing.Point(242, 98)
        Me.RegisterToolStripMenuItem.Name = "RegisterToolStripMenuItem"
        Me.RegisterToolStripMenuItem.Size = New System.Drawing.Size(250, 31)
        Me.RegisterToolStripMenuItem.TabIndex = 6
        Me.RegisterToolStripMenuItem.TabStop = True
        Me.RegisterToolStripMenuItem.Text = "Take Appointment"
        '
        'ListToolStripMenuItem
        '
        Me.ListToolStripMenuItem.AutoSize = True
        Me.ListToolStripMenuItem.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold)
        Me.ListToolStripMenuItem.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.ListToolStripMenuItem.LinkColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.ListToolStripMenuItem.Location = New System.Drawing.Point(228, 209)
        Me.ListToolStripMenuItem.Name = "ListToolStripMenuItem"
        Me.ListToolStripMenuItem.Size = New System.Drawing.Size(276, 31)
        Me.ListToolStripMenuItem.TabIndex = 7
        Me.ListToolStripMenuItem.TabStop = True
        Me.ListToolStripMenuItem.Text = "Appointment Details"
        '
        'FindToolStripMenuItem
        '
        Me.FindToolStripMenuItem.AutoSize = True
        Me.FindToolStripMenuItem.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold)
        Me.FindToolStripMenuItem.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.FindToolStripMenuItem.LinkColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.FindToolStripMenuItem.Location = New System.Drawing.Point(273, 322)
        Me.FindToolStripMenuItem.Name = "FindToolStripMenuItem"
        Me.FindToolStripMenuItem.Size = New System.Drawing.Size(186, 31)
        Me.FindToolStripMenuItem.TabIndex = 8
        Me.FindToolStripMenuItem.TabStop = True
        Me.FindToolStripMenuItem.Text = "Find Patients"
        '
        'Appointments
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.FindToolStripMenuItem)
        Me.Controls.Add(Me.ListToolStripMenuItem)
        Me.Controls.Add(Me.RegisterToolStripMenuItem)
        Me.Name = "Appointments"
        Me.Text = "Appointments"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents RegisterToolStripMenuItem As LinkLabel
    Friend WithEvents ListToolStripMenuItem As LinkLabel
    Friend WithEvents FindToolStripMenuItem As LinkLabel
End Class
