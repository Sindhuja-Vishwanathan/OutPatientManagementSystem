﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class DoctorDetails
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.grdDoctors = New System.Windows.Forms.DataGridView()
        CType(Me.grdDoctors, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'grdDoctors
        '
        Me.grdDoctors.BackgroundColor = System.Drawing.Color.White
        Me.grdDoctors.ColumnHeadersHeight = 40
        Me.grdDoctors.Location = New System.Drawing.Point(12, 12)
        Me.grdDoctors.Name = "grdDoctors"
        Me.grdDoctors.Size = New System.Drawing.Size(776, 426)
        Me.grdDoctors.TabIndex = 0
        '
        'DoctorDetails
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.grdDoctors)
        Me.Name = "DoctorDetails"
        Me.Text = "DoctorDetails"
        CType(Me.grdDoctors, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents grdDoctors As DataGridView
End Class
