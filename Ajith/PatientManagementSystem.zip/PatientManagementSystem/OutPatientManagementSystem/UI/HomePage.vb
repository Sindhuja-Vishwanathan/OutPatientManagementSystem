﻿Imports ClassLib

Public Class HomePage



    Dim log As New EventLog



    Private Sub CloseToolStripMenuItem_Click(sender As Object, e As EventArgs)
        Try

            Dim msg = "Are you sure to Exit?"
            Dim title = "OPMS"
            Dim buttons As MessageBoxButtons = MessageBoxButtons.OKCancel
            Dim result As DialogResult = MessageBox.Show(msg, title, buttons, MessageBoxIcon.Question)
            If result = DialogResult.OK Then
                Application.Exit()
                With log
                    .Source = "OutPatientManagementSystem"
                    .Log = "OPMSLog"
                    .EnableRaisingEvents = True
                    .WriteEntry("Application Exited", EventLogEntryType.Information)
                End With
            End If
        Catch ex As Exception
            With log
                .Source = "OutPatientManagementSystem"
                .Log = "OPMSLog"
                .EnableRaisingEvents = True
                .WriteEntry(ex.Message, EventLogEntryType.Error)
            End With
            Throw ex
        End Try
    End Sub








    Private Sub HomePage_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If Not EventLog.SourceExists("OutPatientManagementSystem") Then
            EventLog.CreateEventSource("OutPatientManagementSystem", "OPMSLog")
        End If
    End Sub


    Private Sub HomeToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HomeToolStripMenuItem.Click
        Try
            My.Application.OpenForms.Cast(Of Form)() _
              .Except({Me}) _
              .ToList() _
              .ForEach(Sub(form) form.Close())
            Me.Activate()
        Catch ex As Exception
            With log
                .Source = "OutPatientManagementSystem"
                .Log = "OPMSLog"
                .EnableRaisingEvents = True
                .WriteEntry(ex.Message, EventLogEntryType.Error)
            End With
            Throw ex
        End Try
    End Sub



    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Try

            Dim msg = "Are you sure to Exit?"
            Dim title = "OPMS"
            Dim buttons As MessageBoxButtons = MessageBoxButtons.OKCancel
            Dim result As DialogResult = MessageBox.Show(msg, title, buttons, MessageBoxIcon.Question)
            If result = DialogResult.OK Then
                Application.Exit()
                With log
                    .Source = "OutPatientManagementSystem"
                    .Log = "OPMSLog"
                    .EnableRaisingEvents = True
                    .WriteEntry("Application Exited", EventLogEntryType.Information)
                End With
            End If
        Catch ex As Exception
            With log
                .Source = "OutPatientManagementSystem"
                .Log = "OPMSLog"
                .EnableRaisingEvents = True
                .WriteEntry(ex.Message, EventLogEntryType.Error)
            End With
            Throw ex
        End Try
    End Sub

    Public app As New Appointments
    Private Sub Appointments_Click(sender As Object, e As EventArgs) Handles Appointments.Click
        app.Show()

    End Sub

    Public docList As New DoctorDetails

    Private Sub DoctorDetails_Click(sender As Object, e As EventArgs) Handles DoctorDetails.Click
        Try

            docList.Show()


        Catch ex As Exception
            With log
                .Source = "OutPatientManagementSystem"
                .Log = "OPMSLog"
                .EnableRaisingEvents = True
                .WriteEntry(ex.Message, EventLogEntryType.Error)
            End With
            Throw ex
        End Try

    End Sub

    Public Sub DoctorListClose()
        docList = Nothing
    End Sub
End Class
