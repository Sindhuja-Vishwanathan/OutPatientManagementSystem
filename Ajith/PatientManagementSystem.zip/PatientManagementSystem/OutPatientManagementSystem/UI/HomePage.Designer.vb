﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class HomePage
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(HomePage))
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.HomeToolStripMenuItem = New System.Windows.Forms.Button()
        Me.Appointments = New System.Windows.Forms.Button()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.Button()
        Me.DoctorDetails = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(24, 24)
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Padding = New System.Windows.Forms.Padding(4, 1, 0, 1)
        Me.MenuStrip1.Size = New System.Drawing.Size(882, 24)
        Me.MenuStrip1.TabIndex = 2
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'HomeToolStripMenuItem
        '
        Me.HomeToolStripMenuItem.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.HomeToolStripMenuItem.Location = New System.Drawing.Point(94, 142)
        Me.HomeToolStripMenuItem.Name = "HomeToolStripMenuItem"
        Me.HomeToolStripMenuItem.Size = New System.Drawing.Size(150, 87)
        Me.HomeToolStripMenuItem.TabIndex = 4
        Me.HomeToolStripMenuItem.Text = "Home"
        Me.HomeToolStripMenuItem.UseVisualStyleBackColor = True
        '
        'Appointments
        '
        Me.Appointments.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Appointments.Location = New System.Drawing.Point(366, 142)
        Me.Appointments.Name = "Appointments"
        Me.Appointments.Size = New System.Drawing.Size(154, 87)
        Me.Appointments.TabIndex = 5
        Me.Appointments.Text = "Appointments"
        Me.Appointments.UseVisualStyleBackColor = True
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Location = New System.Drawing.Point(759, 378)
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(97, 32)
        Me.ExitToolStripMenuItem.TabIndex = 6
        Me.ExitToolStripMenuItem.Text = "Exit"
        Me.ExitToolStripMenuItem.UseVisualStyleBackColor = True
        '
        'DoctorDetails
        '
        Me.DoctorDetails.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DoctorDetails.Location = New System.Drawing.Point(647, 142)
        Me.DoctorDetails.Name = "DoctorDetails"
        Me.DoctorDetails.Size = New System.Drawing.Size(154, 87)
        Me.DoctorDetails.TabIndex = 8
        Me.DoctorDetails.Text = "Doctor Details"
        Me.DoctorDetails.UseVisualStyleBackColor = True
        '
        'HomePage
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoValidate = System.Windows.Forms.AutoValidate.EnableAllowFocusChange
        Me.BackColor = System.Drawing.SystemColors.GrayText
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.ClientSize = New System.Drawing.Size(882, 456)
        Me.Controls.Add(Me.DoctorDetails)
        Me.Controls.Add(Me.ExitToolStripMenuItem)
        Me.Controls.Add(Me.Appointments)
        Me.Controls.Add(Me.HomeToolStripMenuItem)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.IsMdiContainer = True
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "HomePage"
        Me.Text = "HomePage"
        Me.TransparencyKey = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents HomeToolStripMenuItem As Button
    Friend WithEvents Appointments As Button
    Friend WithEvents ExitToolStripMenuItem As Button
    Friend WithEvents DoctorDetails As Button
End Class
