﻿Public Class DoctorDetails

    Dim serialise As New Serialisation
    Dim log As New EventLog
    Private Sub DoctorDetails_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            serialise.XmlDeserialize()
            grdDoctors.DataSource = serialise.ds.Tables(0)
        Catch ex As Exception
            With Log
                .Source = "OutPatientManagementSystem"
                .Log = "OPMSLog"
                .EnableRaisingEvents = True
                .WriteEntry(ex.Message, EventLogEntryType.Error)
            End With
            Throw ex
        End Try
    End Sub

    Private Sub grdDoctors_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles grdDoctors.CellContentClick

    End Sub
End Class