﻿Imports ClassLib
Public Class Appointments



    Dim log As New EventLog

    Private Sub RegisterToolStripMenuItem_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles RegisterToolStripMenuItem.LinkClicked
        Try

            Dim pageReg As New PatientRegister
            pageReg.Show()


        Catch ex As Exception
            With log
                .Source = "OutPatientManagementSystem"
                .Log = "OPMSLog"
                .EnableRaisingEvents = True
                .WriteEntry(ex.Message, EventLogEntryType.Error)
            End With
            Throw ex
        End Try
    End Sub



    Private Shared component As IDBComponent = DataFactory.GetComponent

    Private Sub ListToolStripMenuItem_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles ListToolStripMenuItem.LinkClicked
        Try

            Dim pageList As New PatientList
            pageList.table = component.GetAllPatient
            pageList.Show()



        Catch ex As Exception
            With log
                .Source = "OutPatientManagementSystem"
                .Log = "OPMSLog"
                .EnableRaisingEvents = True
                .WriteEntry(ex.Message, EventLogEntryType.Error)
            End With
            Throw ex
        End Try
    End Sub




    Private Sub FindToolStripMenuItem_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles FindToolStripMenuItem.LinkClicked
        Try
            Dim search As New FindPatients
            search.Show()

        Catch ex As Exception
            With log
                .Source = "OutPatientManagementSystem"
                .Log = "OPMSLog"
                .EnableRaisingEvents = True
                .WriteEntry(ex.Message, EventLogEntryType.Error)
            End With
            Throw ex
        End Try
    End Sub

    Private Sub Appointments_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class